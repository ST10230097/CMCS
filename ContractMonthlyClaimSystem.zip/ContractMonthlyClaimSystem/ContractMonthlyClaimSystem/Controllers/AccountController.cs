﻿using Microsoft.AspNetCore.Mvc;

namespace ContractMonthlyClaimSystem.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            // This is where you would implement actual login logic
            // For now, we'll just redirect to the home page
            return RedirectToAction("Index", "Home");
        }
    }
}
